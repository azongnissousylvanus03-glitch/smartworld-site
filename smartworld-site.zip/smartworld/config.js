// =====================================================
//  CONFIGURATION SMARTWORLD — le seul fichier à modifier
// =====================================================
export default {
  // 1) Dans Supabase : Project Settings > API (ou "API Keys")
  SUPABASE_URL: "https://VOTRE-PROJET.supabase.co",
  SUPABASE_ANON_KEY: "VOTRE_CLE_ANON_OU_PUBLISHABLE",

  // 2) Numéro WhatsApp qui reçoit les commandes (indicatif, sans + ni espaces)
  WHATSAPP: "2290196180447",

  // 3) Affichage
  SHOP_NAME: "SmartWorld",
  SLOGAN: "PC, téléphones & accessoires",
};
