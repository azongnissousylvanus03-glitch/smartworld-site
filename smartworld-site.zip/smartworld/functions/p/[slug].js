// Page "aperçu" d'un produit : /p/<slug>
// WhatsApp et Facebook lisent ces balises pour afficher la PHOTO du produit
// dans le message. Les visiteurs sont redirigés vers le site avec le produit déjà choisi.
import CONFIG from "../../config.js";

const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = n => n == null ? "Prix sur demande" : new Intl.NumberFormat("fr-FR").format(n).replace(/\s/g, " ") + " F";

export async function onRequest({ params, request }) {
  const origin = new URL(request.url).origin;
  const slug = String(params.slug || "");
  const target = `${origin}/?p=${encodeURIComponent(slug)}`;

  let p = null;
  try {
    const r = await fetch(
      `${CONFIG.SUPABASE_URL}/rest/v1/products?slug=eq.${encodeURIComponent(slug)}&active=eq.true&select=name,specs,price,condition,image_url&limit=1`,
      { headers: { apikey: CONFIG.SUPABASE_ANON_KEY } }
    );
    if (r.ok) p = (await r.json())[0] || null;
  } catch (_) { /* on redirige quand même */ }

  if (!p) return Response.redirect(origin + "/", 302);

  const title = `${p.name} — ${fmt(p.price)}`;
  const desc = [p.condition, ...String(p.specs || "").split("\n")].map(s => s.trim()).filter(Boolean).join(" · ");
  const image = p.image_url || `${origin}/icon.png`;

  const html = `<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)} | ${esc(CONFIG.SHOP_NAME)}</title>
<meta name="description" content="${esc(desc)}">
<meta property="og:type" content="product">
<meta property="og:site_name" content="${esc(CONFIG.SHOP_NAME)}">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(desc)}">
<meta property="og:image" content="${esc(image)}">
<meta property="og:url" content="${esc(origin + "/p/" + slug)}">
<meta name="twitter:card" content="summary_large_image">
<meta http-equiv="refresh" content="0;url=${esc(target)}">
</head><body style="font-family:sans-serif;text-align:center;padding:40px">
<p><a href="${esc(target)}">Voir ${esc(p.name)}</a></p>
<script>location.replace(${JSON.stringify(target)})</script>
</body></html>`;

  return new Response(html, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "public, max-age=300" } });
}
